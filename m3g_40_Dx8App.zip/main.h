// File: Main.h
//


#ifndef _MAIN_H_
#define _MAIN_H_


class CMain : public CD3DApplication
{
public:
	ID3DXFont*			m_pD3DXFont;
	LPDIRECT3DTEXTURE8	m_pTx;
	D3DXIMAGE_INFO		m_pImg;

	DWORD				m_dBgn;
	DWORD				m_dEnd;

	RECT				m_Rc;
	FLOAT				m_fA;

public:
	HRESULT Init();
	HRESULT Destroy();
	
	HRESULT Restore();
	HRESULT Invalidate();
	
	HRESULT Render();
	HRESULT FrameMove();
	
	HRESULT ConfirmDevice( D3DCAPS8*, DWORD, D3DFORMAT );
	HRESULT RenderText();
	
public:
	LRESULT MsgProc(HWND hWnd,UINT msg,WPARAM wParam,LPARAM lParam);
	CMain();
};

#endif