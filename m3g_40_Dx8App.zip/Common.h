#ifndef _MAINCOMMON_H_
#define _MAINCOMMON_H_


#define STRICT

#include <vector>
#include <algorithm>
#include <functional>
using namespace std;

#include <basetsd.h>
#include <windows.h>
#include <math.h>
#include <stdio.h>
#include <tchar.h>
#include <malloc.h>

#include <D3D8.h>
#include <D3DX8.h>
#include <DXErr8.h>
#include <d3dx8math.h>

#include <dshow.h>
#include <dplay8.h>
#include <dplobby8.h>
#include <string.h>
#include "D3DApp.h"
#include "D3DUtil.h"
#include "DMUtil.h"
#include "DXUtil.h"
#include "resource.h"


#include "Main.h"


#endif