// File: TEST_CLIENT.cpp
//
////////////////////////////////////////////////////////////////////////////////

#include "Common.h"


CMain*				g_pApp  = NULL;
HINSTANCE			g_hInst = NULL;


INT WINAPI WinMain( HINSTANCE hInst, HINSTANCE, LPSTR, INT )
{
	CMain d3dApp;
	
	g_pApp  = &d3dApp;
	g_hInst = hInst;
	
	if( FAILED( d3dApp.Create( hInst ) ) )
		return 0;
	
	return d3dApp.Run();
}



CMain::CMain()
{
	m_pD3DXFont			= NULL;
	m_pTx				= NULL;
}




HRESULT CMain::Init()
{
	HRESULT hr;

	LOGFONT hFont = { 20, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE,
		ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
		ANTIALIASED_QUALITY, FF_DONTCARE, "Arial" };

	if( FAILED( hr = D3DXCreateFontIndirect( m_pd3dDevice, &hFont, &m_pD3DXFont ) ) )
		return hr;
	
	
	if ( FAILED(hr = D3DXCreateTextureFromFileEx(
		m_pd3dDevice
		, "Texture/mario.png"
		, D3DX_DEFAULT
		, D3DX_DEFAULT
		, D3DX_DEFAULT
		, 0
		, D3DFMT_UNKNOWN
		, D3DPOOL_MANAGED
		, D3DX_FILTER_NONE
		, D3DX_FILTER_NONE
		, 0x00FFFFFF
		, &m_pImg
		, NULL
		, &m_pTx
		)) )
	{
		m_pTx = 0;
		return hr;
	}


	m_dBgn = timeGetTime();

	SetRect(&m_Rc, 0,0, m_pImg.Width/5, m_pImg.Height);
		
	return S_OK;
}


HRESULT CMain::Destroy()
{
	SAFE_RELEASE(	m_pD3DXFont	);
	SAFE_RELEASE(	m_pTx		);

	return S_OK;
}



HRESULT CMain::Restore()
{
	// Set up the textures
	m_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE );
	m_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	m_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );
	
	m_pd3dDevice->SetTextureStageState(0, D3DTSS_MAGFILTER, D3DTEXF_LINEAR);
	m_pd3dDevice->SetTextureStageState(0, D3DTSS_MINFILTER, D3DTEXF_LINEAR);
	m_pd3dDevice->SetTextureStageState(0, D3DTSS_MIPFILTER, D3DTEXF_LINEAR);
	
	//    // Set miscellaneous render states
	m_pd3dDevice->SetRenderState( D3DRS_DITHERENABLE,   TRUE );
	m_pd3dDevice->SetRenderState( D3DRS_SPECULARENABLE, TRUE );
	m_pd3dDevice->SetRenderState( D3DRS_ZENABLE,        TRUE );
	m_pd3dDevice->SetRenderState( D3DRS_LIGHTING,		FALSE);
	
	m_pD3DXFont->OnResetDevice();
	
	return S_OK;
}


HRESULT CMain::Invalidate()
{
	m_pD3DXFont->OnLostDevice();
	return S_OK;
}


HRESULT CMain::FrameMove()
{
	m_dEnd = timeGetTime();

	if(m_dEnd> (m_dBgn + 100) )
	{
		m_Rc.left += m_pImg.Width/5;
		m_Rc.right = m_Rc.left + m_pImg.Width/5;

		if(m_Rc.right> m_pImg.Width)
		{
			m_Rc.left = 0;
			m_Rc.right= m_pImg.Width/5;
		}

		m_dBgn = m_dEnd;
	}


	m_fA = D3DXToRadian(m_dEnd/10);	

	return S_OK;
}


HRESULT CMain::Render()
{
	m_pd3dDevice->Clear( 0L, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER|D3DCLEAR_STENCIL, 0xFF006699, 1.0f, 0L );
	
	if(FAILED( m_pd3dDevice->BeginScene() ) )
		return -1;
	
	D3DXVECTOR2 vcScl(4,4);
	D3DXVECTOR2 vcPos(100,100);
	D3DXVECTOR2 vcRot(100,100);
	
	m_pd3dSprite->Draw(m_pTx, &m_Rc, &vcScl, &vcRot, m_fA, &vcPos, D3DXCOLOR(1,1,1,0.6f));

	RenderText();

	m_pd3dDevice->EndScene();
	
	return S_OK;
}


HRESULT CMain::RenderText()
{
	D3DCOLOR fontColor        = D3DCOLOR_ARGB(255,255,255,0);
	D3DCOLOR fontWarningColor = D3DCOLOR_ARGB(255,0,255,255);
	TCHAR szMsg[MAX_PATH] = TEXT("");
		
	sprintf(szMsg, "%s %s", m_strDeviceStats, m_strFrameStats);

	RECT rc={10, 0, this->m_dwCreationWidth, 30};
	
	m_pD3DXFont->DrawText(szMsg, -1, &rc, 0, D3DXCOLOR(1,1,0,1));
	return S_OK;
}



LRESULT CMain::MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam )
{
	switch( msg )
	{
	case WM_PAINT:
		{
			if( m_bLoadingApp )
			{
			}
			break;
		}
		
	}
	
	return CD3DApplication::MsgProc( hWnd, msg, wParam, lParam );
}