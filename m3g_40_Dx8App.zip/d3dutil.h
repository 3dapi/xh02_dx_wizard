//-----------------------------------------------------------------------------
// File: D3DUtil.h
//
// Desc: Helper functions and typing shortcuts for Direct3D programming.
//-----------------------------------------------------------------------------
#ifndef D3DUTIL_H
#define D3DUTIL_H
#include <D3D8.h>
#include <D3DX8Math.h>




//-----------------------------------------------------------------------------
// Name: D3DUtil_InitMaterial()
// Desc: Initializes a D3DMATERIAL8 structure, setting the diffuse and ambient
//       colors. It does not set emissive or specular colors.
//-----------------------------------------------------------------------------
VOID D3DUtil_InitMaterial( D3DMATERIAL8& mtrl, FLOAT r=0.0f, FLOAT g=0.0f,
                                               FLOAT b=0.0f, FLOAT a=1.0f );




//-----------------------------------------------------------------------------
// Name: D3DUtil_InitLight()
// Desc: Initializes a D3DLIGHT structure, setting the light position. The
//       diffuse color is set to white, specular and ambient left as black.
//-----------------------------------------------------------------------------
VOID D3DUtil_InitLight( D3DLIGHT8& light, D3DLIGHTTYPE ltType,
                        FLOAT x=0.0f, FLOAT y=0.0f, FLOAT z=0.0f );




//-----------------------------------------------------------------------------
// Name: D3DUtil_CreateTexture()
// Desc: Helper function to create a texture. It checks the root path first,
//       then tries the DXSDK media path (as specified in the system registry).
//-----------------------------------------------------------------------------
HRESULT D3DUtil_CreateTexture( LPDIRECT3DDEVICE8 pd3dDevice, TCHAR* strTexture,
                               LPDIRECT3DTEXTURE8* ppTexture,
                               D3DFORMAT d3dFormat = D3DFMT_UNKNOWN );




//-----------------------------------------------------------------------------
// Name: D3DUtil_SetColorKey()
// Desc: Changes all texels matching the colorkey to transparent, black.
//-----------------------------------------------------------------------------
HRESULT D3DUtil_SetColorKey( LPDIRECT3DTEXTURE8 pTexture, DWORD dwColorKey );




//-----------------------------------------------------------------------------
// Name: D3DUtil_CreateVertexShader()
// Desc: Assembles and creates a file-based vertex shader
//-----------------------------------------------------------------------------
HRESULT D3DUtil_CreateVertexShader( LPDIRECT3DDEVICE8 pd3dDevice, 
                                    TCHAR* strFilename, DWORD* pdwVertexDecl,
                                    DWORD* pdwVertexShader );

                                    
                                    
                                    
//-----------------------------------------------------------------------------
// Name: D3DUtil_GetCubeMapViewMatrix()
// Desc: Returns a view matrix for rendering to a face of a cubemap.
//-----------------------------------------------------------------------------
D3DXMATRIX D3DUtil_GetCubeMapViewMatrix( DWORD dwFace );




//-----------------------------------------------------------------------------
// Name: D3DUtil_GetRotationFromCursor()
// Desc: Returns a quaternion for the rotation implied by the window's cursor
//       position.
//-----------------------------------------------------------------------------
D3DXQUATERNION D3DUtil_GetRotationFromCursor( HWND hWnd,
                                              FLOAT fTrackBallRadius=1.0f );




//-----------------------------------------------------------------------------
// Name: D3DUtil_SetDeviceCursor
// Desc: Builds and sets a cursor for the D3D device based on hCursor.
//-----------------------------------------------------------------------------
HRESULT D3DUtil_SetDeviceCursor( LPDIRECT3DDEVICE8 pd3dDevice, HCURSOR hCursor,
                                 BOOL bAddWatermark );





//-----------------------------------------------------------------------------
// Helper macros for pixel shader instructions
//-----------------------------------------------------------------------------

// Parameter writemasks
#define D3DPSP_WRITEMASK_B   D3DSP_WRITEMASK_0
#define D3DPSP_WRITEMASK_G   D3DSP_WRITEMASK_1
#define D3DPSP_WRITEMASK_R   D3DSP_WRITEMASK_2
#define D3DPSP_WRITEMASK_A   D3DSP_WRITEMASK_3
#define D3DPSP_WRITEMASK_C   (D3DPSP_WRITEMASK_B|D3DPSP_WRITEMASK_G|D3DPSP_WRITEMASK_R)
#define D3DPSP_WRITEMASK_ALL (D3DSP_WRITEMASK_0|D3DSP_WRITEMASK_1|D3DSP_WRITEMASK_2|D3DSP_WRITEMASK_3)
#define D3DPSP_WRITEMASK_10  (D3DSP_WRITEMASK_0|D3DSP_WRITEMASK_1)
#define D3DPSP_WRITEMASK_32  (D3DSP_WRITEMASK_2|D3DSP_WRITEMASK_3)

// Source and destination parameter token
#define D3DPS_REGNUM_MASK(_Num)   ( (1L<<31) | ((_Num)&D3DSP_REGNUM_MASK) )
#define D3DPS_DST(_Num)           ( D3DPS_REGNUM_MASK(_Num) | D3DSPR_TEMP | D3DPSP_WRITEMASK_ALL )
#define D3DPS_SRC_TEMP(_Num)      ( D3DPS_REGNUM_MASK(_Num) | D3DSP_NOSWIZZLE | D3DSPR_TEMP )
#define D3DPS_SRC_INPUT(_Num)     ( D3DPS_REGNUM_MASK(_Num) | D3DSP_NOSWIZZLE | D3DSPR_INPUT )
#define D3DPS_SRC_CONST(_Num)     ( D3DPS_REGNUM_MASK(_Num) | D3DSP_NOSWIZZLE | D3DSPR_CONST )
#define D3DPS_SRC_TEXTURE(_Num)   ( D3DPS_REGNUM_MASK(_Num) | D3DSP_NOSWIZZLE | D3DSPR_TEXTURE )
#define D3DVS_SRC_ADDR(_Num)      ( D3DPS_REGNUM_MASK(_Num) | D3DSP_NOSWIZZLE | D3DSPR_ADDR )
#define D3DVS_SRC_RASTOUT(_Num)   ( D3DPS_REGNUM_MASK(_Num) | D3DSP_NOSWIZZLE | D3DSPR_RASTOUT )
#define D3DVS_SRC_ATTROUT(_Num)   ( D3DPS_REGNUM_MASK(_Num) | D3DSP_NOSWIZZLE | D3DSPR_ATTROUT )
#define D3DVS_SRC_TEXCRDOUT(_Num) ( D3DPS_REGNUM_MASK(_Num) | D3DSP_NOSWIZZLE | D3DSPR_TEXCRDOUT )

// Temp destination registers
#define D3DS_DR0   D3DPS_DST(0)
#define D3DS_DR1   D3DPS_DST(1)
#define D3DS_DR2   D3DPS_DST(2)
#define D3DS_DR3   D3DPS_DST(3)
#define D3DS_DR4   D3DPS_DST(4)
#define D3DS_DR5   D3DPS_DST(5)
#define D3DS_DR6   D3DPS_DST(6)
#define D3DS_DR7   D3DPS_DST(7)

// Temp source registers
#define D3DS_SR0   D3DPS_SRC_TEMP(0)
#define D3DS_SR1   D3DPS_SRC_TEMP(1)
#define D3DS_SR2   D3DPS_SRC_TEMP(2)
#define D3DS_SR3   D3DPS_SRC_TEMP(3)
#define D3DS_SR4   D3DPS_SRC_TEMP(4)
#define D3DS_SR5   D3DPS_SRC_TEMP(5)
#define D3DS_SR6   D3DPS_SRC_TEMP(6)
#define D3DS_SR7   D3DPS_SRC_TEMP(7)

// Texture parameters
#define D3DS_T0   D3DPS_SRC_TEXTURE(0)
#define D3DS_T1   D3DPS_SRC_TEXTURE(1)
#define D3DS_T2   D3DPS_SRC_TEXTURE(2)
#define D3DS_T3   D3DPS_SRC_TEXTURE(3)
#define D3DS_T4   D3DPS_SRC_TEXTURE(4)
#define D3DS_T5   D3DPS_SRC_TEXTURE(5)
#define D3DS_T6   D3DPS_SRC_TEXTURE(6)
#define D3DS_T7   D3DPS_SRC_TEXTURE(7)

// Constant (factor) source parameters
#define D3DS_C0     D3DPS_SRC_CONST(0)
#define D3DS_C1     D3DPS_SRC_CONST(1)
#define D3DS_C2     D3DPS_SRC_CONST(2)
#define D3DS_C3     D3DPS_SRC_CONST(3)
#define D3DS_C4     D3DPS_SRC_CONST(4)
#define D3DS_C5     D3DPS_SRC_CONST(5)
#define D3DS_C6     D3DPS_SRC_CONST(6)
#define D3DS_C7     D3DPS_SRC_CONST(7)

// Iterated source parameters (0==Diffuse, 1==specular)
#define D3DS_V0     D3DPS_SRC_INPUT(0)
#define D3DS_V1     D3DPS_SRC_INPUT(1)




#endif // D3DUTIL_H
