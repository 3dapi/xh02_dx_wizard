
#pragma warning(disable : 4786)

#include <vector>

#include <windows.h>
#include <shellapi.h>
#include <shlobj.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>
#include <IO.h>
#include <time.h>

#include "resource.h"


//	For Using SHGetSpecialFolderPath()
//	Defined ShlObj.h
//	#define CSIDL_DESKTOP                   0x0000
//	#define CSIDL_INTERNET                  0x0001
//	#define CSIDL_PROGRAMS                  0x0002
//	#define CSIDL_CONTROLS                  0x0003
//	#define CSIDL_PRINTERS                  0x0004
//	#define CSIDL_PERSONAL                  0x0005
//	#define CSIDL_FAVORITES                 0x0006
//	#define CSIDL_STARTUP                   0x0007
//	#define CSIDL_RECENT                    0x0008
//	#define CSIDL_SENDTO                    0x0009
//	#define CSIDL_BITBUCKET                 0x000a
//	#define CSIDL_STARTMENU                 0x000b
//	#define CSIDL_DESKTOPDIRECTORY          0x0010
//	#define CSIDL_DRIVES                    0x0011
//	#define CSIDL_NETWORK                   0x0012
//	#define CSIDL_NETHOOD                   0x0013
//	#define CSIDL_FONTS                     0x0014
//	#define CSIDL_TEMPLATES                 0x0015
//	#define CSIDL_COMMON_STARTMENU          0x0016
//	#define CSIDL_COMMON_PROGRAMS           0X0017
//	#define CSIDL_COMMON_STARTUP            0x0018
//	#define CSIDL_COMMON_DESKTOPDIRECTORY   0x0019
//	#define CSIDL_APPDATA                   0x001a
//	#define CSIDL_PRINTHOOD                 0x001b
//	#define CSIDL_ALTSTARTUP                0x001d
//	#define CSIDL_COMMON_ALTSTARTUP         0x001e
//	#define CSIDL_COMMON_FAVORITES          0x001f
//	#define CSIDL_INTERNET_CACHE            0x0020
//	#define CSIDL_COOKIES                   0x0021
//	#define CSIDL_HISTORY                   0x0022

// Not defined. So U'll make it.
#define CSIDL_COMMON_DESKTOPDIRECTORY	0x0019
#define CSIDL_LOCAL_APPDATA				0x001C

#define CSIDL_INTERNET_CACHE			0x0020
#define CSIDL_COOKIES					0x0021
#define CSIDL_HISTORY					0x0022
#define CSIDL_COMMON_APPDATA			0x0023
#define CSIDL_WINDOWS					0x0024
#define CSIDL_SYSTEM					0x0025
#define CSIDL_PROGRAM_FILES				0x0026
#define CSIDL_MYPICTURES				0x0027
#define CSIDL_PROFILE					0x0028
#define CSIDL_SYSTEMX86					0x0029
#define CSIDL_PROGRAM_FILESX86			0x002A
#define CSIDL_PROGRAM_FILES_COMMON		0x002B
#define CSIDL_PROGRAM_FILES_COMMONX86	0x002C
#define CSIDL_COMMON_TEMPLATES			0x002D
#define CSIDL_COMMON_DOCUMENTS			0x002E
#define CSIDL_COMMON_ADMINTOOLS			0x002F


typedef std::vector<std::string >				lsStr;

void LnFile_Finds(lsStr* pOut, char* sPath, char* sFile);




void LnUtil_SHGetSpecialFolder(char* pBuf/*out*/, INT nFolder)
{
	SHGetSpecialFolderPath( NULL, pBuf, nFolder, 0);
}




void main()
{
	HINSTANCE hInst = GetModuleHandle(NULL);
	lsStr	pOut;
	char	sFolder[] = "MSDev98";
	char	sProgramFiles[512];

	printf("Install Modified Directx9 Wizard..\n", sProgramFiles);

//	printf("Search program files Folder\n");
	LnUtil_SHGetSpecialFolder(sProgramFiles, CSIDL_PROGRAM_FILES);


	printf("Search Visual Studio Folder\n");
	LnFile_Finds(&pOut, sProgramFiles, sFolder);

	if(pOut.empty())
	{
		printf("Find Visual Studio Folder Failed\n");
		return;
	}

	if(pOut.empty())
	{
		printf("Find Microsoft Visual Studio Folder Failed\n");
		return;
	}

	char sPath[2048];
	char sFile[2048];

	sprintf(sPath, "%s/%s/Template", pOut[0].c_str(), sFolder);
	sprintf(sFile,"%s/%s", sPath, "dxappwiz9Modified.awx");

	

	printf("Install...\n");
	
	HRSRC hawx = FindResource( hInst, MAKEINTRESOURCE(IDR_AWX1), "awx");

	DWORD dwSize = SizeofResource(hInst,hawx);
	HGLOBAL hMem = LoadResource(hInst, hawx);
	LPVOID ptr = LockResource(hMem);

	FILE* fp = fopen(sFile, "wb");

	if(fp)
	{
		fwrite(ptr, dwSize, 1, fp);
		fclose(fp);
	}


	UnlockResource(hMem);

	FreeResource(hMem);

	printf("Install Completed!!!\n");
}



void LnFile_Finds(lsStr* pOut, char* sPath, char* sFile)
{
	int			bFind = 0;

	char		sSearchPath[2048];
	_finddata_t	fd;
	long		handle;
	int			result=1;

	sprintf(sSearchPath,"%s/*.*", sPath);
	handle=_findfirst(sSearchPath,&fd);
	
	if (handle == -1)
		return;
	
	while (result != -1)
	{
		if(fd.name[0] !='.')
		{
			if((fd.attrib & _A_SUBDIR))
			{
				if(0== _stricmp(fd.name, sFile))
				{
					char sT[1024];
					sprintf(sT, "%s", sPath);
					pOut->push_back(sT);

					bFind = 1;
					break;
				}
				else
				{
					char sSearchFolder[2048];

					sprintf(sSearchFolder, "%s/%s", sPath, fd.name);
					LnFile_Finds(pOut, sSearchFolder, sFile);
				}
			}
		}
		
		result=_findnext(handle,&fd);
		
	}

	_findclose(handle);
	
}
