// Implementation of the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMain::CMain()
{
	m_dwCreationWidth			= 800;
	m_dwCreationHeight			= 600;
	strcpy(m_strClassName, TEXT( "$$root$$" ));

	m_bStartFullscreen			= false;
	m_bShowCursorWhenFullscreen	= true;

	m_pVB			= NULL;

$$IF(D3DFONT)
	// Create a D3D font using d3dfont.cpp
	m_pFont			= new CD3DFont( _T("Arial"), 12, D3DFONT_BOLD );
$$ELSE
	m_pD3DXFont		= NULL;
$$ENDIF

	ZeroMemory( &m_UserInput, sizeof(m_UserInput) );

	m_fWorldRotX	= 0.0f;
	m_fWorldRotY	= 0.0f;
}



HRESULT CMain::Init()
{
	// TODO: create device objects
	HRESULT hr=-1;


	// Create the vertex buffer
	hr = m_pd3dDevice->CreateVertexBuffer(
			3*2*sizeof(VtxN)
			, 0
			, VtxN::FVF
			, D3DPOOL_MANAGED
			, &m_pVB
			, NULL);

	if( FAILED( hr))
		return -1;


	// Fill the vertex buffer with 2 triangles
	VtxN* pVertices;

	hr = m_pVB->Lock( 0, 0, (void**)&pVertices, 0 );

	if( FAILED( hr ) )
		return -1;

	// Front triangle
	pVertices[0].position = D3DXVECTOR3( -1.0f, -1.0f,  0.0f );
	pVertices[0].normal   = D3DXVECTOR3(  0.0f,  0.0f, -1.0f );
	pVertices[1].position = D3DXVECTOR3(  0.0f,  1.0f,  0.0f );
	pVertices[1].normal   = D3DXVECTOR3(  0.0f,  0.0f, -1.0f );
	pVertices[2].position = D3DXVECTOR3(  1.0f, -1.0f,  0.0f );
	pVertices[2].normal   = D3DXVECTOR3(  0.0f,  0.0f, -1.0f );

	// Back triangle
	pVertices[3].position = D3DXVECTOR3( -1.0f, -1.0f,  0.0f );
	pVertices[3].normal   = D3DXVECTOR3(  0.0f,  0.0f,  1.0f );
	pVertices[4].position = D3DXVECTOR3(  1.0f, -1.0f,  0.0f );
	pVertices[4].normal   = D3DXVECTOR3(  0.0f,  0.0f,  1.0f );
	pVertices[5].position = D3DXVECTOR3(  0.0f,  1.0f,  0.0f );
	pVertices[5].normal   = D3DXVECTOR3(  0.0f,  0.0f,  1.0f );

	m_pVB->Unlock();


$$IF(D3DFONT)
	// Init the font
	m_pFont->InitDeviceObjects( m_pd3dDevice );
$$ELSE
	// Create a D3D font using D3DX
	D3DXFONT_DESC hFont =
	{
		16, 0
		, FW_NORMAL
		, 1					// Mip Level
		, FALSE				// Italic
		, HANGUL_CHARSET	// Charset
		, OUT_DEFAULT_PRECIS// Output Precision
		, ANTIALIASED_QUALITY// Qulity
		, FF_DONTCARE		// Pitch And Family
		, "Arial"			// FaceName
	};

	if( FAILED( hr = D3DXCreateFontIndirect( m_pd3dDevice, &hFont, &m_pD3DXFont ) ) )
		return -1;
$$ENDIF

	return S_OK;
}


// Called when the app is exiting, or the device is being changed,
// this function deletes any device dependent objects.
HRESULT CMain::Destroy()
{
	// TODO: Cleanup any objects created in Init()
	SAFE_RELEASE( m_pVB );

$$IF(D3DFONT)
	m_pFont->Destroy();
	SAFE_DELETE(	m_pFont	);
$$ELSE
	SAFE_RELEASE(	m_pD3DXFont	);
$$ENDIF

	return S_OK;
}


// The device exists, but may have just been Reset().
HRESULT CMain::Restore()
{
	HRESULT hr = -1;

	// Antialias Enable
	m_pd3dDevice->SetRenderState (D3DRS_MULTISAMPLEANTIALIAS, TRUE);
	m_pd3dDevice->SetRenderState (D3DRS_ANTIALIASEDLINEENABLE, TRUE);

	// Setup a material
	D3DMATERIAL9 mtrl;
	D3DUtil_InitMaterial( mtrl, 1.0f, 0.0f, 0.0f );
	m_pd3dDevice->SetMaterial( &mtrl );

	// Set up the textures
	m_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE );
	m_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	m_pd3dDevice->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );
	m_pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_MODULATE );
	m_pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE );
	m_pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE );
	m_pd3dDevice->SetSamplerState( 0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR );
	m_pd3dDevice->SetSamplerState( 0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR );

	// Set miscellaneous render states
	m_pd3dDevice->SetRenderState( D3DRS_DITHERENABLE,   FALSE );
	m_pd3dDevice->SetRenderState( D3DRS_SPECULARENABLE, FALSE );
	m_pd3dDevice->SetRenderState( D3DRS_ZENABLE,		TRUE );
	m_pd3dDevice->SetRenderState( D3DRS_AMBIENT,		0x000F0F0F );

	// Set the world matrix
	D3DXMATRIX matIdentity;
	D3DXMatrixIdentity( &matIdentity );
	m_pd3dDevice->SetTransform( D3DTS_WORLD,  &matIdentity );

	// Set up our view matrix. A view matrix can be defined given an eye point,
	// a point to lookat, and a direction for which way is up. Here, we set the
	// eye five units back along the z-axis and up three units, look at the
	// origin, and define "up" to be in the y-direction.

	D3DXMATRIX matView;
	D3DXVECTOR3 vFromPt		= D3DXVECTOR3( 0.0f, 0.0f, -5.0f );
	D3DXVECTOR3 vLookatPt	= D3DXVECTOR3( 0.0f, 0.0f, 0.0f );
	D3DXVECTOR3 vUpVec		= D3DXVECTOR3( 0.0f, 1.0f, 0.0f );

	D3DXMatrixLookAtLH( &matView, &vFromPt, &vLookatPt, &vUpVec );
	m_pd3dDevice->SetTransform( D3DTS_VIEW, &matView );

	// Set the projection matrix
	D3DXMATRIX matProj;
	FLOAT fAspect = ((FLOAT)m_d3dsdBackBuffer.Width) / m_d3dsdBackBuffer.Height;
	D3DXMatrixPerspectiveFovLH( &matProj, D3DX_PI/4, fAspect, 1.0f, 5000.0f );
	m_pd3dDevice->SetTransform( D3DTS_PROJECTION, &matProj );


	// Set up lighting states
	D3DLIGHT9 light;
	D3DUtil_InitLight( light, D3DLIGHT_DIRECTIONAL, -1.0f, -1.0f, 2.0f );
	m_pd3dDevice->SetLight( 0, &light );
	m_pd3dDevice->LightEnable( 0, TRUE );
	m_pd3dDevice->SetRenderState( D3DRS_LIGHTING, TRUE );


$$IF(D3DFONT)
	// Restore the font
	m_pFont->RestoreDeviceObjects();
$$ELSE
	m_pD3DXFont->OnResetDevice();
$$ENDIF

	return S_OK;
}




// Invalidates device objects.  Paired with Restore()
// Cleanup any objects created in Restore()
HRESULT CMain::Invalidate()
{
$$IF(D3DFONT)
	m_pFont->Invalidate();
$$ELSE
	m_pD3DXFont->OnLostDevice();
$$ENDIF

	return S_OK;
}


// Called once per frame, the call is the entry point for animating the scene.
HRESULT CMain::FrameMove()
{
	// Update user input state
	UpdateInput( &m_UserInput );

	// Update the world state according to user input
	D3DXMATRIX matWorld;
	D3DXMATRIX matRotY;
	D3DXMATRIX matRotX;
	
	if( m_UserInput.bRotateLeft && !m_UserInput.bRotateRight )
		m_fWorldRotY += m_fElapsedTime;
	else if( m_UserInput.bRotateRight && !m_UserInput.bRotateLeft )
		m_fWorldRotY -= m_fElapsedTime;
	
	if( m_UserInput.bRotateUp && !m_UserInput.bRotateDown )
		m_fWorldRotX += m_fElapsedTime;
	else if( m_UserInput.bRotateDown && !m_UserInput.bRotateUp )
		m_fWorldRotX -= m_fElapsedTime;
	
	D3DXMatrixRotationX( &matRotX, m_fWorldRotX );
	D3DXMatrixRotationY( &matRotY, m_fWorldRotY );
	
	D3DXMatrixMultiply( &matWorld, &matRotX, &matRotY );
	m_pd3dDevice->SetTransform( D3DTS_WORLD, &matWorld );

	return S_OK;
}


// Called once per frame, the call is the entry point for 3d
// rendering. This function sets up render states, clears the
// viewport, and renders the scene.
HRESULT CMain::Render()
{
	// Clear the viewport
	m_pd3dDevice->Clear( 0L
						, NULL
						, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER | D3DCLEAR_STENCIL
						, 0x00006699
						, 1.0f
						, 0L );

	// Begin the scene
	if( FAILED( m_pd3dDevice->BeginScene() ) )
		return -1;

	// Render the vertex buffer contents
	m_pd3dDevice->SetStreamSource( 0, m_pVB, 0, sizeof(VtxN) );
	m_pd3dDevice->SetFVF( VtxN::FVF );
	m_pd3dDevice->DrawPrimitive( D3DPT_TRIANGLELIST, 0, 2 );


//	for ID3DXSprite*
//	m_pd3dSprite->Begin(D3DXSPRITE_ALPHABLEND);
//	m_pd3dSprite->Draw(LPDIRECT3DTEXTURE9 pTexture
//						, CONST RECT *pSrcRect
//						, CONST D3DXVECTOR3 *pCenter
//						, CONST D3DXVECTOR3 *pPosition
//						, D3DCOLOR Color);
//
//	m_pd3dSprite->End();



	RenderText();

	// End the scene.
	m_pd3dDevice->EndScene();

	return S_OK;
}



HRESULT CMain::RenderText()
{
	D3DCOLOR fontColor		= D3DCOLOR_ARGB(255,255,255,0);
	TCHAR szMsg[MAX_PATH]	= {0};

	sprintf( szMsg, "%s %s", m_strDeviceStats, m_strFrameStats );

$$IF(D3DFONT)
	FLOAT fNextLine = 20.0f;
	fNextLine -= 20.0f;
	m_pFont->DrawText( 2, fNextLine, fontColor, szMsg );
$$ELSE

	RECT rct={ 10, 10, m_d3dsdBackBuffer.Width - 20, 10+30};
	m_pD3DXFont->DrawText(NULL, szMsg, -1, &rct, 0, fontColor );
$$ENDIF

	return S_OK;
}




// Update the user input.  Called once per frame

void CMain::UpdateInput( UserInput* pUserInput )
{
	pUserInput->bRotateUp	= ( m_bActive && (GetAsyncKeyState( VK_UP   ) & 0x8000) == 0x8000 );
	pUserInput->bRotateDown = ( m_bActive && (GetAsyncKeyState( VK_DOWN ) & 0x8000) == 0x8000 );
	pUserInput->bRotateLeft = ( m_bActive && (GetAsyncKeyState( VK_LEFT ) & 0x8000) == 0x8000 );
	pUserInput->bRotateRight= ( m_bActive && (GetAsyncKeyState( VK_RIGHT) & 0x8000) == 0x8000 );
}




// Overrrides the main WndProc(MsgProc).
// handling (e.g. processing mouse, keyboard, or menu commands).

LRESULT CMain::MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam )
{
	switch( msg )
	{
		case WM_PAINT:
		{
			if( m_bLoadingApp )
			{
				// Draw on the window tell the user that the app is loading
				HDC hDC = GetDC( hWnd );

				ReleaseDC( hWnd, hDC );
			}
			break;
		}

	}

	return CD3DApplication::MsgProc( hWnd, msg, wParam, lParam );
}




