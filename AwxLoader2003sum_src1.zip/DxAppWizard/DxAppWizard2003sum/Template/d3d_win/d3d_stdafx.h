//
//
////////////////////////////////////////////////////////////////////////////////

#ifndef __STDAFX_H_
#define __STDAFX_H_

#pragma once


#define STRICT
#define WIN32_LEAN_AND_MEAN

#define _WIN32_WINNT			0x0400
#define _WIN32_WINDOWS			0x0400

#define DIRECTINPUT_VERSION		0x0800


#pragma warning( disable : 4018)
#pragma warning( disable : 4098)
#pragma warning( disable : 4100)
#pragma warning( disable : 4238)
#pragma warning( disable : 4245)
#pragma warning( disable : 4503)
#pragma warning( disable : 4663)
#pragma warning( disable : 4786)


// Static Library
#pragma comment(lib, "shell32.lib"		)
#pragma comment(lib, "comctl32.lib"		)



#include <windows.h>
#include <commctrl.h>
#include <commdlg.h>
#include <basetsd.h>
#include <math.h>
#include <stdio.h>
#include <d3dx9.h>
#include <dxerr9.h>
#include <tchar.h>
$$IF(DINPUT)
#include <dinput.h>
$$ENDIF
$$IF(DPLAY)
#include <dplay8.h>
#include <dplobby8.h>
$$ENDIF
#include "DXUtil.h"
#include "D3DEnum.h"
#include "D3DSettings.h"
#include "D3DApp.h"
$$IF(D3DFONT)
#include "D3DFont.h"
$$ENDIF
$$IF(X_FILE)
#include "D3DFile.h"
$$ENDIF
#include "D3DUtil.h"
$$IF(ACTIONMAPPER)
#include "DIUtil.h"
$$ENDIF
$$IF(DMUSIC)
#include "DMUtil.h"
$$ENDIF
$$IF(DSOUND)
#include "DSUtil.h"
$$ENDIF
$$IF(DPLAY)
#include "NetConnect.h"
$$ENDIF
$$IF(DPLAYVOICE)
#include "NetVoice.h"
$$ENDIF
#include "resource.h"


// TODO: create user header files.



//

#include "Main.h"

#endif



