// Interface for the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _MAIN_H_
#define _MAIN_H_


#pragma once


// Custom D3D vertex format used by the vertex buffer
struct VtxN
{
	D3DXVECTOR3 position;       // vertex position
	D3DXVECTOR3 normal;         // vertex normal

	enum {FVF=(D3DFVF_XYZ|D3DFVF_NORMAL),};
};




// Struct to store the current input state
struct UserInput
{
	// TODO: change as needed
	BOOL bRotateUp;
	BOOL bRotateDown;
	BOOL bRotateLeft;
	BOOL bRotateRight;
};




// Application class. The base class (CD3DApplication) provides the
// generic functionality needed in all Direct3D samples. CMain
// adds functionality specific to this sample program.

class CMain : public CD3DApplication
{
protected:
    LPDIRECT3DVERTEXBUFFER9 m_pVB;                  // Vextex buffer

$$IF(D3DFONT)
	CD3DFont*               m_pFont;                // Font for drawing text
$$ELSE
	ID3DXFont*              m_pD3DXFont;            // D3DX font
$$ENDIF

    UserInput               m_UserInput;            // Struct for storing user input

    FLOAT                   m_fWorldRotX;           // World rotation state X-axis
    FLOAT                   m_fWorldRotY;           // World rotation state Y-axis

public:
    virtual HRESULT Init();
    virtual HRESULT Destroy();

    virtual HRESULT Restore();
    virtual HRESULT Invalidate();

    virtual HRESULT FrameMove();
    virtual HRESULT Render();

    HRESULT RenderText();
	void	UpdateInput( UserInput*);

public:
	CMain();
    LRESULT MsgProc( HWND, UINT, WPARAM, LPARAM);
};


extern CMain* g_pApp;

#endif



