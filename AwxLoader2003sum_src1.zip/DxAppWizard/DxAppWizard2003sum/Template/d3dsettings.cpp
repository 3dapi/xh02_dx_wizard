//-----------------------------------------------------------------------------
// File: D3DSettings.cpp
//
// Desc: Settings class and change-settings dialog class for the Direct3D 
//       samples framework library.
//-----------------------------------------------------------------------------
#define STRICT
$$IF(DLG)
#include "stdafx.h"
$$ENDIF
#include <windows.h>
#include <windowsx.h>
#include <tchar.h>
#include <stdio.h>
#include <D3D9.h>
#include "DXUtil.h"
#include "D3DUtil.h"
#include "D3DEnum.h"
#include "D3DSettings.h"
#include "resource.h"


